var searchData=
[
  ['plansza',['Plansza',['../classplansza_1_1Plansza.html',1,'plansza']]],
  ['player',['Player',['../classgracz_1_1Player.html',1,'gracz']]],
  ['przegrana',['przegrana',['../classwalka_1_1Walka.html#a9ca30ed0e19b14647a5266eb8bf84b2d',1,'walka::Walka']]]
];
