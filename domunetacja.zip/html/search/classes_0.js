var searchData=
[
  ['plansza',['Plansza',['../classplansza_1_1Plansza.html',1,'plansza']]],
  ['player',['Player',['../classgracz_1_1Player.html',1,'gracz']]]
];
