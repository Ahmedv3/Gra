var searchData=
[
  ['walka',['Walka',['../classwalka_1_1Walka.html',1,'walka']]]
];
