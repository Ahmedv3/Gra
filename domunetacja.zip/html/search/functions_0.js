var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classgracz_1_1Player.html#ae0cdfba04e1ef6e78d1c253b2fdaed92',1,'gracz.Player.__init__()'],['../classwalka_1_1Walka.html#a4be320e1f21f17c15f3f8e6f3bbdcb69',1,'walka.Walka.__init__()'],['../classplansza_1_1Plansza.html#a60ef0d68f1dd73fc94bfaa072aef821b',1,'plansza.Plansza.__init__()']]]
];
