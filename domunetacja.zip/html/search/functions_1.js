var searchData=
[
  ['atak',['atak',['../classwalka_1_1Walka.html#ae863869a3145061ef7dd83563e5170da',1,'walka::Walka']]],
  ['atak_5fprzeciwnik',['atak_przeciwnik',['../classwalka_1_1Walka.html#af7925bbd5c9585f0bf6decd8c38aeed0',1,'walka::Walka']]]
];
