var searchData=
[
  ['draw',['draw',['../classplansza_1_1Plansza.html#ad966e173f18bf3973027358b48ddc79f',1,'plansza::Plansza']]]
];
