var searchData=
[
  ['ekran_5fstartowy',['ekran_startowy',['../classplansza_1_1Plansza.html#ac2b4562df343b0585f1f4761995f97df',1,'plansza::Plansza']]],
  ['events',['events',['../classplansza_1_1Plansza.html#a79d58e6a564d4e7ea5663d1a385c2b31',1,'plansza::Plansza']]]
];
