var searchData=
[
  ['kontynuacja',['kontynuacja',['../classwalka_1_1Walka.html#adb5ea2faaa190221438b50a525c96d96',1,'walka::Walka']]]
];
