var searchData=
[
  ['move',['move',['../classgracz_1_1Player.html#a9c6945cd22bd400e35655462e5ca492b',1,'gracz::Player']]]
];
