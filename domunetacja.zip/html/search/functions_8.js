var searchData=
[
  ['random',['random',['../classgracz_1_1Player.html#adb67c96b3f9ff4296f31f9441490c0ff',1,'gracz::Player']]]
];
