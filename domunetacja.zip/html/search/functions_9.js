var searchData=
[
  ['sprawdz_5fwalke',['sprawdz_walke',['../classgracz_1_1Player.html#a65fdc3b44f370a41a1d8f29b4df82277',1,'gracz::Player']]],
  ['sprawdz_5fzdarzenia',['sprawdz_zdarzenia',['../classgracz_1_1Player.html#a0867c1bc7bf87bbbdd2d55da0b7ab04b',1,'gracz::Player']]]
];
