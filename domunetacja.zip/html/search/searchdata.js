var indexSectionsWithContent =
{
  0: "_adekmoprsw",
  1: "pw",
  2: "_adekmoprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

